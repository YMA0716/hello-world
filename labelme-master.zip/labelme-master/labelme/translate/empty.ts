<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>Canvas</name>
    <message>
        <location filename="../widgets/canvas.py" line="235"/>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="249"/>
        <source>Click &amp; drag to move point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="259"/>
        <source>Click &amp; drag to move shape &apos;%s&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../app.py" line="91"/>
        <source>Flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="107"/>
        <source>Polygon Labels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="112"/>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="118"/>
        <source>Label List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="123"/>
        <source>Search Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="134"/>
        <source>File List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="184"/>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="184"/>
        <source>Quit application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="186"/>
        <source>&amp;Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="186"/>
        <source>Open image or label file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="188"/>
        <source>&amp;Open Dir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="188"/>
        <source>Open Dir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="190"/>
        <source>&amp;Next Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="190"/>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="198"/>
        <source>&amp;Prev Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="198"/>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="206"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="206"/>
        <source>Save labels to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="208"/>
        <source>&amp;Save As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="208"/>
        <source>Save labels to a different file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="212"/>
        <source>&amp;Delete File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="212"/>
        <source>Delete current label file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="220"/>
        <source>&amp;Change Output Dir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="220"/>
        <source>Change where annotations are loaded/saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="228"/>
        <source>Save &amp;Automatically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="228"/>
        <source>Save automatically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="238"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="238"/>
        <source>Close current file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="240"/>
        <source>Polygon &amp;Line Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="240"/>
        <source>Choose polygon line color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="243"/>
        <source>Polygon &amp;Fill Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="243"/>
        <source>Choose polygon fill color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="247"/>
        <source>Keep Previous Annotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="247"/>
        <source>Toggle &quot;keep pevious annotation&quot; mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="255"/>
        <source>Create Polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="255"/>
        <source>Start drawing polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="263"/>
        <source>Create Rectangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="263"/>
        <source>Start drawing rectangles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="271"/>
        <source>Create Circle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="271"/>
        <source>Start drawing circles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="279"/>
        <source>Create Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="279"/>
        <source>Start drawing lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="287"/>
        <source>Create Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="287"/>
        <source>Start drawing points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="295"/>
        <source>Create LineStrip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="295"/>
        <source>Start drawing linestrip. Ctrl+LeftClick ends creation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="303"/>
        <source>Edit Polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="303"/>
        <source>Move and edit the selected polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="307"/>
        <source>Delete Polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="307"/>
        <source>Delete the selected polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="310"/>
        <source>Duplicate Polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="310"/>
        <source>Create a duplicate of the selected polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="314"/>
        <source>Undo last point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="314"/>
        <source>Undo last drawn point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="317"/>
        <source>Add Point to Edge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="317"/>
        <source>Add point to the nearest edge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="321"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="321"/>
        <source>Undo last add and edit of shape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="324"/>
        <source>&amp;Hide
Polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="324"/>
        <source>Hide all polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="327"/>
        <source>&amp;Show
Polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="327"/>
        <source>Show all polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="331"/>
        <source>&amp;Tutorial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="331"/>
        <source>Show tutorial page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="336"/>
        <source>Zoom in or out of the image. Also accessible with {} and {} from the canvas.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="336"/>
        <source>Ctrl+Wheel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="350"/>
        <source>Zoom &amp;In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="350"/>
        <source>Increase zoom level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="353"/>
        <source>&amp;Zoom Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="353"/>
        <source>Decrease zoom level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="356"/>
        <source>&amp;Original size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="356"/>
        <source>Zoom to original size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="360"/>
        <source>&amp;Fit Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="360"/>
        <source>Zoom follows window size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="364"/>
        <source>Fit &amp;Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="364"/>
        <source>Zoom follows window width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="380"/>
        <source>&amp;Edit Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="380"/>
        <source>Modify the label of the selected polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="384"/>
        <source>Shape &amp;Line Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="384"/>
        <source>Change the line color for this specific shape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="387"/>
        <source>Shape &amp;Fill Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="387"/>
        <source>Change the fill color for this specific shape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="390"/>
        <source>Fill Drawing Polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="390"/>
        <source>Fill polygon while drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="467"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="467"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="467"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="467"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="467"/>
        <source>Open &amp;Recent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="553"/>
        <source>%s started.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1091"/>
        <source>Invalid label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1091"/>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1032"/>
        <source>Error saving label data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1032"/>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1213"/>
        <source>Error opening file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1172"/>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1176"/>
        <source>Loading %s...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1186"/>
        <source>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Make sure &lt;i&gt;%s&lt;/i&gt; is a valid label file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1218"/>
        <source>Error reading %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1213"/>
        <source>&lt;p&gt;Make sure &lt;i&gt;{0}&lt;/i&gt; is a valid image file.&lt;br/&gt;Supported image formats: {1}&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1239"/>
        <source>Loaded %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1352"/>
        <source>Image &amp; Label files (%s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1354"/>
        <source>%s - Choose Image or Label file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1370"/>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1383"/>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1415"/>
        <source>%s - Choose File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1438"/>
        <source>Label files (*%s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1438"/>
        <source>Choose File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1470"/>
        <source>You are about to permanently delete this label file, proceed anyway?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1553"/>
        <source>Attention</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1506"/>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1507"/>
        <source>Save annotations?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1562"/>
        <source>Choose line color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1571"/>
        <source>Choose fill color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1551"/>
        <source>You are about to permanently delete {} polygons, proceed anyway?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.py" line="1601"/>
        <source>%s - Open Directory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
